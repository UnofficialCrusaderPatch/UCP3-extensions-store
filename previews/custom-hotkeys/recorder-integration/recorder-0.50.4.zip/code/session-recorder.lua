local Base = require('code/replay-streams')
local store = require('code/sessions')
local native = require('code/native')
local validation = require('code/validation')
local work=require('code/maintenance-journal')
local verification=require('code/replay-verification')
local Session = setmetatable({}, {__index=Base})

function Session:new(engine,config)
  local o=Base:new({name='unused'})
  o.engine=engine
  o.input=require('code/input-state').new(o)
  o.halt=core.allocate(4,true)
  -- Native tick admission: viewing pause must freeze maintenance too. Loading
  -- still needs native preparation calls, so arm only after restoration.
  o.playbackActive=core.allocate(4,true)
  o.resultsHold=core.allocate(4,true)
  o.status='idle'
  o.autoRecord=not config or config.autoRecord~=false
  if config and config.singleplayerRngDiagnostics then
    o.rngTrace=require('code/rng-attribution').new(engine)
  end
  return setmetatable(o,{__index=self})
end

-- Called only after the native lobby accepted Start, before its RNG seed call.
local function beginMatch(self)
  if self.engine.loading or not self.engine:singlePlayer() or self.mode=='play' then return end
  if self.mode=='record' and self.status~='armed' then self:reset() end
  if self.autoRecord and self.mode=='none' then self:startRecording() end
end

function Session:beginMatch()
  return self.input:transition(function() beginMatch(self) end)
end

function Session:onMenuView(view)
  -- Natural match results return directly to the lobby (20), bypassing the
  -- manual Quit Mission transition (61). Seal from the last observed tick;
  -- the result/lobby screens are not additional simulation boundaries.
  if not self.engine.loading and (view==20 or view==41 or view==61) then self:reset() end
end

function Session:saveCopy(name)
  assert(self.engine:singlePlayer() and self.mode=='record' and self.status=='recording'
    and self.active and self.observedTick,'No active recording to save yet')
  for _,key in ipairs({'commandsFile','rngFile','infoFile'}) do assert(self[key]:flush()) end
  if self.engine.battle then self.engine.battle:write(self.manifest) end
  self:sealBoundary()
  return store.copy(self.manifest,name,self.manifest.finalRngHash)
end

-- Decode the retained ending boundary only when publishing a replay. Native
-- menu transitions may already have changed the world, so never resample it.
function Session:sealBoundary()
  local rng,resources=self.boundary:read()
  self.manifest.finalRng=self.boundary:rngState()
  self.manifest.finalResources=self.engine:resourceState(resources)
  self.manifest.finalRngHash=require('code/native-hash').sha256(rng)
end

function Session:guard(callback)
  local ok, reason=xpcall(callback,debug.traceback)
  if not ok then
    if self.status=='error' and (self.active or self.mode~='none') then return false end -- retain the first session failure
    self.status='error'; self.error=tostring(reason)
    if self.rngTrace then self.rngTrace:observe('finish','session failed') end
    local recordingFailed=self.mode=='record'
    local pauseGame=self.engine:localSession() and (self.active or self.mode=='play')
    local stopSimulation=pauseGame and not recordingFailed
    core.writeInteger(self.halt,stopSimulation and 1 or 0)
    if pauseGame then self.engine:pause() end
    if recordingFailed then
      if self.phaseNative then self.phaseNative:stop() end
      -- A capture failure invalidates the recording, not the player's match.
      -- Keep the first error visible, but detach capture before native dispatch
      -- continues. Ordinary unpause must restore normal commands and ticking.
      self.active=false; self.capturePending=nil
      self.engine:setScope(false)
      self.engine:resetCommands()
    end
    if self.mode=='play' then pcall(self.engine.abortPlayback,self.engine) end
    print('Replay stopped: ' .. self.error)
    if self.manifest then
      pcall(store.write,store.path(self.manifest.id)..'/last-error.txt',self.error)
      if self.mode=='record' then
        if self.engine.battle and self.observedTick then pcall(self.engine.battle.write,self.engine.battle,self.manifest) end
        self.manifest.status='failed'; pcall(store.save,self.manifest)
      elseif self.mode=='play' then
        pcall(self.playbackResult,self,'failed',{error=self.error})
      end
    end
    pcall(Base.closeFiles,self) -- cleanup must not replace the first failure
  end
  return ok
end

function Session:playbackResult(status,details)
  local result=details or {}
  result.status=status
  result.started=self.playbackStarted
  result.lastTick=self.engine:tick()
  result.commands=self.playedCommands or 0
  store.write(store.path(self.manifest.id)..'/last-playback.json',json:encode(result))
end

function Session:startRecording()
  assert(self.mode=='none','A replay session is already active')
  assert(self.engine:singlePlayer(),'Recording currently supports single-player Skirmish')
  local automarket=require('code/automarket-replay').current()
  self.manifest=store.new(native.profile)
  self.manifest.verificationProfile=verification.recordingProfile()
  self.manifest.automarket=automarket
  self:setName(store.path(self.manifest.id)..'/stream')
  self:openFiles('w')
  if self.phaseNative then
    self.manifest.phaseProfile=work.PROFILE
    self.phaseFile=assert(io.open(store.path(self.manifest.id)..'/'..work.FILE,'wb'))
  end
  self.mode='record'; self.status='armed'; self.active=false
  self.error=nil; self.observedTick=false
  self.firstDesync=nil
  self.boundary=self.boundary or self.engine:newRecordingBoundary()
  self.boundary:clear()
  self.executedTick=nil; self.executedBatchSize=0
  self.engine:resetCommands()
  self.engine:setScope(true)
  core.writeInteger(self.halt,0)
end

function Session:activateRecording()
  self:reconcileMode()
  if self.mode~='record' or self.status~='armed' then return end
  local path=store.path(self.manifest.id)
  self.engine:saveSnapshot(path..'/start.sav')
  local rng=self.engine:rngData()
  store.write(path..'/rng.bin',rng)
  self.manifest.snapshotHash=require('code/native-hash').file(path..'/start.sav',1024*1024*1024)
  self.manifest.rngHash=require('code/native-hash').sha256(rng)
  self.manifest.player=self.engine:player()
  self.manifest.startTick=self.engine:tick()
  self.manifest.lastTick=self.manifest.startTick
  self.manifest.snapshotOriginMonth=self.engine:calendarMonth()
  self.manifest.startResources=self.engine:resourceState()
  self.manifest.finalResources=self.manifest.startResources
  local r=self.engine:rngState()
  local seed=core.readInteger(self.engine.rng+4)
  self:saveInfo(0,seed,seed,r[1],r[2],r[4],r[3])
  self.manifest.status='recording'; store.save(self.manifest)
  self.active=true; self.status='recording'
  self.snapshots=require('code/replay-snapshots').new(self)
  if self.phaseNative then self.phaseNative:start() end
  if self.engine.battle then self.engine.battle:begin() end
  if self.rngTrace then self.rngTrace:observe('begin',self.manifest,'record') end
  print('Recording '..self.manifest.id)
end

function Session:prepareRecording()
  -- The start-menu callback returns before the first simulation boundary.
  -- Capture after that initialization, at the same boundary playback verifies.
  if self.mode=='record' and self.status=='armed' then self.capturePending=true end
end

function Session:preparePlayback(id,prepared,progress)
  assert(self.mode=='none','A replay session is already active')
  assert(self.engine:singlePlayer(),'Replay playback is single-player only')
  return require('code/replay-preparation').prepare(id,self.engine,prepared,progress)
end

local function startPlayback(self,id,prepared,ready,cached)
  assert(self.mode=='none','A replay session is already active')
  assert(self.engine:singlePlayer(),'Replay playback is single-player only')
  if not id then
    for _, item in ipairs(store.list()) do
      if item.status=='complete' and item.variant==native.profile.name then id=item.id; break end
    end
  end
  assert(id,'No completed recording is available')
  ready=ready or self:preparePlayback(id,prepared)
  local manifest=ready.manifest
  self.playbackInfo=ready.info
  assert(manifest.id==id,'Prepared replay identity differs')
  assert(store.compatible(manifest),'Replay requires its recorded UCP settings')
  local path=store.path(id)
  local snapshotPath,rng=ready.snapshotPath,ready.rng
  if cached then snapshotPath,rng=cached.snapshotPath,cached.rng end
  self:setName(path..'/stream')
  self:openFiles('r')
  if manifest.multiplayer then self.tickFile=assert(io.open(path..'/ticks.bin','rb')) end
  if manifest.phaseProfile then self.phaseFile=assert(io.open(path..'/'..work.FILE,'rb')) end
  self.nextWork=nil; self.workEnded=nil
  self.manifest=manifest
  self.firstDesync=nil
  self.preparedWorlds=ready.worlds
  self.mode='play'; self.status='loading'; self.active=false
  core.writeInteger(self.playbackActive,0)
  -- The native victory/defeat banner leaves the simulation after eight real
  -- seconds. Hold that presentation transition throughout playback, including
  -- verified completion/failure; only leaving the replay releases it.
  core.writeInteger(self.resultsHold,1)
  self.error=nil
  self.playedCommands=0
  self.playbackStarted=os.date('!%Y-%m-%dT%H:%M:%SZ')
  -- Invalidate an earlier success before touching native state. An interrupted
  -- or failed repeat must never retain the previous run's finished report.
  self:playbackResult('loading')
  self.engine:setScope(true)
  core.writeInteger(self.halt,0)
  if manifest.multiplayer then
    local offline=require('code/offline-runtime')
    offline.load(self.engine,snapshotPath,offline.roster(manifest.multiplayer))
  else self.engine:loadSnapshot(snapshotPath) end
  local bytes={}; for i=1,#rng do bytes[i]=rng:byte(i) end
  core.writeBytes(self.engine.rng,bytes)
  self:checkRngData(cached and cached.point.rngHash or manifest.rngHash,'starting save')
  assert(self.engine:tick()==(cached and cached.point.tick or manifest.startTick),'Loaded save has a different starting tick')
  assert(self.engine:player()==manifest.player,'Loaded save has a different player slot')
  if cached then
    assert(require('code/native-hash').sha256(self.engine:rngData()..self.engine:resourceData())==cached.point.stateHash,
      'Restored snapshot state differs')
    self:restoreBookmark(cached.point.bookmark)
    self.engine.journal.executed=cached.point.commands
    self.engine.journal.nextSequence=cached.point.commands+1
  else self:checkResources(manifest.startResources,'starting save') end
  self.active=true; self.status='playing'; self.playedCommands=0
  if cached then self.playedCommands=cached.point.commands end
  self.snapshots=require('code/replay-snapshots').new(self,ready)
  core.writeInteger(self.playbackActive,1)
  if self.rngTrace then self.rngTrace:observe('begin',self.manifest,'play') end
  self:playbackResult('playing')
  print('Playing '..id)
end

function Session:startPlayback(id,prepared,ready,cached)
  return self.input:transition(function() startPlayback(self,id,prepared,ready,cached) end)
end

function Session:onExecutedCommand(command)
  if self.status~='recording' or not self.active then return end
  validation.sessionCommand(command,self.manifest)
  self.executedBatchSize=command.time==self.executedTick and self.executedBatchSize+1 or 1
  self.executedTick=command.time
  assert(self.executedBatchSize<=100,'Recording exceeds the supported 100-command dispatch batch')
  assert(self.commandsFile:write(json:encode(command)..'\n'))
  assert(self.commandsFile:flush())
  self.manifest.commandCount=self.manifest.commandCount+1
end

function Session:onUnclockedWorld()
  assert(self.active and self.status=='recording','Unexpected unclocked world capture')
  work.capture(self)
  work.write(self,2,1)
end

function Session:beforeCommandWork()
  if self.mode=='record' then work.capture(self)
  elseif self.status=='playing' then work.play(self) end
end

function Session:feed()
  self:reconcileMode()
  if self.status~='playing' then return end
  local now=self.engine:tick()
  local count=0
  while true do
    local c=self:peekCommand()
    if not c or c.time>now then return end
    assert(c.time>=now,'Replay command missed its simulation tick')
    count=count+1
    assert(count<=100,'Replay exceeds the native 100-command dispatch batch')
    assert(self.engine:canSchedule(),'Native command ring has no room for the due replay batch')
    validation.sessionCommand(c,self.manifest)
    self.engine:scheduleCommand(c)
    self:consumeSavedCommand()
    self.playedCommands=self.playedCommands+1
  end
end

function Session:onTick()
  self:reconcileMode()
  if self.capturePending then
    self.capturePending=nil
    self:activateRecording()
  end
  if not self.active then return end
  if self.status=='recording' then work.capture(self)
  elseif self.status=='playing' then work.play(self) end
  local now=self.engine:tick()
  -- Flush before replay checks can halt at the first mismatch.
  if self.snapshots then
    self.snapshots:observe()
    if self.mode=='play' and self.snapshots:atBoundary(now) then return end
  end
  if self.rngTrace and now%64==0 then self.rngTrace:observe('checkpoint') end
  if self.status=='recording' then
    if self.engine.battle then self.engine.battle:observe() end
    self.manifest.lastTick=now
    -- Keep the exact last observed boundary; quitting may already change native state.
    self.boundary:capture()
    self.observedTick=true
    if now%verification.interval(self.manifest.verificationProfile)==0 then
      local rng,resources=self.boundary:read()
      local line=json:encode(verification.capture(self.engine,self.manifest.verificationProfile,
        now,self.boundary:rngState(),rng,resources))
      assert(self.rngFile:write(line..'\n')); assert(self.rngFile:flush())
    end
  elseif self.status=='playing' then
    assert(now<=self.manifest.lastTick,'Replay passed its ending tick')
    if self.manifest.multiplayer then
      local ticks=require('code/tick-journal')
      if now==self.manifest.lastTick then ticks.input(self.engine,self.manifest.finalRng)
      else
        assert(not self.pendingTick,'Previous replay simulation tick did not return')
        local frame=ticks.decode(assert(self.tickFile:read(ticks.SIZE),'Replay tick journal ended early'))
        assert(frame.time==now,'Replay simulation tick differs')
        ticks.input(self.engine,frame.before)
        self.pendingTick=frame
      end
    end
    if now%verification.interval(self.manifest.verificationProfile)==0 then
      local line=self.rngFile:read()
      assert(line,'Replay verification data ended early')
      local expected=json:decode(line)
      local actual=self.engine:rngState()
      assert(expected.time==now,'Replay checkpoint tick differs')
      for i=1,4 do
        if actual[i]~=expected.rng[i] then
          self.firstDesync={time=now,expected=expected.rng,actual=actual}
          store.write(store.path(self.manifest.id)..'/desync.json',json:encode(self.firstDesync))
          error('RNG divergence at tick '..now..' (field '..i..')')
        end
      end
      if self.manifest.verificationProfile==verification.COMPACT then
        local actualHash=verification.capture(self.engine,verification.COMPACT,now,actual).stateHash
        if actualHash~=expected.stateHash then
          self.firstDesync={kind='state',time=now,expected=expected.stateHash,actual=actualHash}
          store.write(store.path(self.manifest.id)..'/desync.json',json:encode(self.firstDesync))
          error('Replay state divergence at tick '..now)
        end
      else
        self:checkResources(expected.resources,'checkpoint')
        self:checkRngData(expected.rngHash,'checkpoint')
      end
    end
    if now>=self.manifest.lastTick then
      work.finished(self)
      assert(self.playedCommands==self.manifest.commandCount,'Replay ended before all commands were scheduled')
      assert(not self.engine:commandsPending(),'Replay ended with commands still waiting to execute')
      assert(self.engine.journal.executed==self.manifest.commandCount,'Replay native execution count differs')
      local actual=self.engine:rngState()
      for i=1,4 do assert(actual[i]==self.manifest.finalRng[i],'Final RNG state differs at tick '..now) end
      self:checkResources(self.manifest.finalResources,'ending state')
      self:checkRngData(self.manifest.finalRngHash,'ending state')
      core.writeInteger(self.halt,1)
      if self.manifest.multiplayer and self.manifest.nextReplay
        and self.preparedWorlds[self.manifest.nextReplay] then
        self.status='transition'; self.nextReplay=self.manifest.nextReplay
      else self.status='finished'; self.engine:pause() end
      if self.rngTrace then self.rngTrace:observe('finish','playback finished') end
      local incomplete=self.preparedWorlds and self.preparedWorlds.incomplete
      self:playbackResult(self.nextReplay and 'segment-finished' or (incomplete and 'finished-prefix' or 'finished'),
        {rngCheckpoints='matched',fullRngCheckpoints='matched',resourceCheckpoints='matched',recovery=incomplete})
    end
  end
end

function Session:afterTick()
  if self.snapshots and self.snapshots:afterTick() then return end
  if self.nextReplay then
    -- processGameTick has unwound. Outer-loop callbacks still follow this point;
    -- their replacement-world safety remains part of the execution-phase audit.
    local id,prepared=self.nextReplay,self.preparedWorlds
    if self.snapshots then self.snapshots:transition(id)
    else self:reset(); self:startPlayback(id,prepared) end
    return
  end
  local frame=self.pendingTick
  if not frame then return end
  self.pendingTick=nil
  assert(self.engine:tick()==frame.time+1,'Replay simulation tick advanced unexpectedly')
  require('code/tick-journal').check(self.engine,frame.after,'after simulation')
end

function Session:checkRngData(expected,phase)
  validation.hash(expected,'full RNG hash')
  local actual=require('code/native-hash').sha256(self.engine:rngData())
  if actual~=expected then
    self.firstDesync={kind='rng-state',time=self.engine:tick(),phase=phase,expected=expected,actual=actual}
    store.write(store.path(self.manifest.id)..'/desync.json',json:encode(self.firstDesync))
    error('Full RNG state divergence at tick '..self.engine:tick()..' ('..phase..')')
  end
end

function Session:checkResources(expected,phase)
  validation.resources(expected)
  local actual=self.engine:resourceState()
  for i=1,200 do
    if actual[i]~=expected[i] then
      local player=math.floor((i-1)/25)+1
      local resource=(i-1)%25
      self.firstDesync={kind='resources',time=self.engine:tick(),phase=phase,
        player=player,resource=resource,expected=expected[i],actual=actual[i]}
      store.write(store.path(self.manifest.id)..'/desync.json',json:encode(self.firstDesync))
      error('Resource divergence at tick '..self.engine:tick()..' (player '..player..', resource '..resource..')')
    end
  end
end

local function reset(self)
  if self.snapshots then self.snapshots:close(); self.snapshots=nil end
  if self.phaseNative then self.phaseNative:stop() end
  self.nextWork=nil; self.workEnded=nil
  core.writeInteger(self.playbackActive,0)
  core.writeInteger(self.resultsHold,0)
  if self.rngTrace then self.rngTrace:observe('finish','session ended') end
  self.capturePending=nil
  local reportOk,reportError=true,nil
  if self.mode=='play' and (self.status=='playing' or self.status=='loading') and self.manifest then
    reportOk,reportError=pcall(self.playbackResult,self,'interrupted')
  end
  if self.mode=='play' then self.engine:abortPlayback() end
  self.pendingTick=nil
  self.nextReplay=nil; self.preparedWorlds=nil
  require('code/offline-runtime').leave(self.engine)
  self.engine:setScope(false)
  self.engine:resetCommands()
  core.writeInteger(self.halt,0)
  local manifest=self.mode=='record' and self.manifest
  local complete=manifest and self.active and self.observedTick and self.status=='recording'
  self.active=false
  local closed,reason=pcall(Base.reset,self)
  if manifest then
    if complete and closed then
      local ok,finishError=pcall(function()
        self:sealBoundary()
        if self.engine.battle then self.engine.battle:write(manifest) end
        store.finish(manifest)
        self.lastCompletedReplay=manifest.id
      end)
      if not ok then
        manifest.status='failed'; pcall(store.save,manifest)
        error(finishError)
      end
    else
      manifest.status=(self.status=='error' or not closed) and 'failed' or 'cancelled'
      store.save(manifest)
    end
  end
  assert(closed,reason)
  self.status='idle'; self.manifest=nil
  self.observedTick=false; self.error=nil
  if self.boundary then self.boundary:clear() end
  core.writeInteger(self.halt,0)
  assert(reportOk,reportError)
end

function Session:reset()
  return self.input:transition(function() reset(self) end)
end

function Session:reconcileMode()
  if self.mode~='none' and not self.engine:localSession() then
    self.status='error'
    self.error='Replay session ended when entering multiplayer'
    self:reset()
  end
end

function Session:discardFiles() end -- Cancelling never deletes a previous recording.
return Session
