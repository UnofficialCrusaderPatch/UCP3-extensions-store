local native=require('code/native')
local profiles=require('code/scoped-sites')
local emitter=require('code/scoped-code')
local M={}

function M.verify(seed)
  local sites=assert(profiles[native.profile.name])
  for _,site in ipairs(sites) do
    if site.kind~='seed' or seed~=nil then
      require('code/hook-check').verify(site,'Recorder simulation hook conflicts at '..site.name)
    end
  end
  return sites
end

function M.install(sites,enabled,mode,seed,offline)
  local returnAddresses={}
  for _,site in ipairs(sites) do
    if site.kind~='seed' or seed~=nil then
      local size=#emitter.build(site,enabled,mode,seed,0,nil,offline)
      local target=core.allocateCode(size)
      core.writeCode(target,emitter.build(site,enabled,mode,seed,target,returnAddresses,offline))
      core.writeCode(site.address,emitter.jump(site.address,target,#site.bytes))
    end
  end
  return returnAddresses
end

function M.installTick(site,enabled,mode,halt,callback,originalCallback,offline,exitAddress)
  local tick={address=site.address,bytes=site.bytes,kind='raw',patch='tick',
    halt=halt,callback=callback,originalCallback=originalCallback,skipTick=assert(exitAddress)}
  M.install({tick},enabled,mode,nil,offline)
end

function M.tickEntry(sites,halt,playback,internalWork)
  local site=sites.tickEntry
  return {address=site.address,bytes=site.bytes,kind='raw',patch='tickEntry',
    halt=halt,playback=playback,paused=sites.paused,
    menu=sites.haltingMenu.address,gameCore=sites.gameCore,internalWork=internalWork}
end
return M
