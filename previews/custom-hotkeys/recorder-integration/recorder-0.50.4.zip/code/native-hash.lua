-- UCP itself imports Advapi32 for signature verification. Reuse its SHA-256
-- provider rather than hashing tens of MiB in the interpreter on a game tick.
local platform=require('code/platform')
local binary=require('code/binary-memory')
local M={CHUNK=65536}
local api,buffers,busy,nativeRead,nativeClose

local function initialize()
  if api then return end
  binary.prepare()
  local functions={}
  for name,count in pairs({CryptAcquireContextA=5,CryptCreateHash=5,CryptHashData=4,
      CryptGetHashParam=5,CryptDestroyHash=1,CryptReleaseContext=2}) do
    functions[name]=platform.stdcall('advapi32.dll',name,count)
  end
  local storage=core.allocate(M.CHUNK+64,true)
  local allocated={input=storage,provider=storage+M.CHUNK+4,
    hash=storage+M.CHUNK+8,digest=storage+M.CHUNK+12,length=storage+M.CHUNK+44}
  api,buffers=functions,allocated
  -- These are the framework's own CRT functions, paired with its VFS opener.
  -- Reading straight into our buffer avoids a Lua string -> byte table -> native
  -- buffer round trip on RPS versions whose writeString truncates at NUL.
  if io.openFileDescriptor and io.ucrt and io.ucrt._read and io.ucrt._close then
    nativeRead=core.exposeCode(io.ucrt._read,3,0)
    nativeClose=core.exposeCode(io.ucrt._close,1,0)
  end
end

function M.prepare()
  initialize()
  assert(M.sha256('abc')=='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
    'Windows SHA-256 self-test failed')
end

local function hashChunks(nextChunk)
  assert(not busy,'Nested native hashing')
  initialize(); busy=true
  local provider,hash
  local ok,result=pcall(function()
    -- PROV_RSA_AES, CRYPT_VERIFYCONTEXT: ephemeral context, no persisted keys.
    assert(api.CryptAcquireContextA(buffers.provider,0,0,24,-268435456)~=0,'Cannot acquire SHA-256 provider')
    provider=core.readInteger(buffers.provider)
    assert(api.CryptCreateHash(provider,0x800c,0,0,buffers.hash)~=0,'Cannot create SHA-256 hash')
    hash=core.readInteger(buffers.hash)
    while true do
      local chunk=nextChunk()
      if not chunk then break end
      local size=type(chunk)=='number' and chunk or #chunk
      assert(size>0 and size<=M.CHUNK,'Invalid SHA-256 chunk')
      if type(chunk)=='string' then binary.write(buffers.input,chunk) end
      assert(api.CryptHashData(hash,buffers.input,size,0)~=0,'Cannot update SHA-256 hash')
    end
    core.writeInteger(buffers.length,32)
    assert(api.CryptGetHashParam(hash,2,buffers.digest,buffers.length,0)~=0
      and core.readInteger(buffers.length)==32,'Cannot finish SHA-256 hash')
    local digest=core.readString(buffers.digest,32)
    assert(#digest==32,'Short SHA-256 digest')
    return (digest:gsub('.',function(c) return string.format('%02x',c:byte()) end))
  end)
  -- Release both objects on every error path before allowing the next hash.
  local hashClosed=not hash or api.CryptDestroyHash(hash)~=0
  local providerClosed=not provider or api.CryptReleaseContext(provider,0)~=0
  busy=false
  assert(ok,result)
  assert(hashClosed and providerClosed,'Cannot release SHA-256 context')
  return result
end
function M.sha256(data)
  assert(type(data)=='string','Invalid native hashing input')
  local offset=1
  return hashChunks(function()
    if offset>#data then return end
    local chunk=data:sub(offset,offset+M.CHUNK-1); offset=offset+#chunk
    return chunk
  end)
end
-- Consumers that parse bytes use onChunk. Progress-only callers need a count,
-- not a Lua copy of every native input buffer (hundreds of MiB for assets).
function M.file(path,limit,onChunk,onProgress)
  initialize()
  if nativeRead then
    -- _O_RDONLY | _O_BINARY; VFS alias resolution and access policy stay with UCP.
    local fd=io.openFileDescriptor(path,0x8000,0)
    assert(type(fd)=='number' and fd>=0 and fd<2147483648,'Missing file: '..path)
    local ok,result=pcall(function()
      local count=0
      return hashChunks(function()
        local size=nativeRead(fd,buffers.input,M.CHUNK)
        assert(size>=0 and size<=M.CHUNK,'Cannot read hashed file: '..path)
        if size==0 then return end
        count=count+size; assert(count<=limit,'File exceeds replay size limit: '..path)
        if onChunk then onChunk(core.readString(buffers.input,size),count) end
        if onProgress then onProgress(count) end
        return size
      end)
    end)
    local closed=nativeClose(fd)==0
    assert(ok,result)
    assert(closed,'Cannot close hashed file: '..path)
    return result
  end
  local file=assert(io.open(path,'rb'),'Missing file: '..path)
  local ok,result=pcall(function()
    local count=0
    local digest=hashChunks(function()
      local chunk,reason=file:read(M.CHUNK)
      assert(not reason,reason)
      if chunk then
        count=count+#chunk; assert(count<=limit,'File exceeds replay size limit: '..path)
        if onChunk then onChunk(chunk,count) end
        if onProgress then onProgress(count) end
      end
      return chunk
    end)
    return digest
  end)
  local closed=file:close()
  assert(ok and closed,result or 'Cannot close hashed file')
  return result
end
return M
